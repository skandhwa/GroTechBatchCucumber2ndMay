Feature: Search Product Feature

  Background: 
    Given user opens the browser url
    And user enters the username as "test123"
    And user enters the password as "test@123"
    When user clicks on login button
    Then user will be navigated to the homepage of the application

@regression
  Scenario Outline: Validate Search Product Functionality
    And user will then search for "mobile phones"
    And user hits enter
    Then a list of mentioned "mobile phones" should be displayed

@sanity1 @regression1
  Scenario Outline: Validate Search Product Functionality
    And user tries to look for the search history
    And user checks that 20 products he searched in last 7 days
    Then user wants to look for details for products
