Feature: Login Scenario feature

  Scenario: Validate Login functionality with correct credentials
    Given user opens the browser url
    And user enters the username as "abcd"
    And user enters the password as "test@1234"
    When user clicks on login button
    Then user will be navigated to the homepage of the application


@sanity2
  Scenario: Validate Login functionality with incorrect credentails
    Given user opens the browser url
    And user enters the username as "hgtf"
    And user enters the password as "test@1234"
    When user clicks on login button
    But user gets an error with incorrect credentials
  #  Then user closes the browser and correct his credentails
    
    
    
    
