Feature: Validate Login Functionality for guru 99

  Scenario Outline: Validate Login scenario
    Given user opens the guru99 registration form
    And user enters the username as "<username>" in form
    And user enters the password as "<password>" in form
    When user clicks on the login button
    Then user will be navigated to guru99 homepage

    Examples: 
      | username   | password |
      | mngr660340 | japugYr  |
