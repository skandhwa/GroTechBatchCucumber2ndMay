Feature: Demo for Cucumber data Table

  Scenario: Add details to Application form
    Given user opens the application form
    And user enters the below details
      | firstname | lastname | address | emailaddress      | phone      |
      | John      | bell     | CA      | john123@gmail.com | 9800776543 |
