package StepDefinition20;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition20 {
	
	WebDriver driver=new ChromeDriver();
	
	
	@Before(order='A')
	public void beforeTest()
	{
		System.out.println("Code for connect to DB");
	}
	
	@Before(order='A')
	public void beforeTest2()
	{
		System.out.println("Code to connect with API");
	}
	
	
	@After
	public void afterTest()
	{
		System.out.println("post condition added");
	}
	
	@Before("@sanity")
	public void beforeSanity()
	{
		System.out.println("pre condition only before sanity");
	}
	
	@After("@sanity")
	public void afterSanity()
	{
		System.out.println("post condition only after sanity");
	}
	
	@Before("@regression")
	public void beforeRegression()
	{
		System.out.println("pre condition only before sanity");
	}
	
	@After("@regression")
	public void afterRegression()
	{
		System.out.println("post condition only after sanity");
	}
	
	
	
	@Given("user opens the browser url")
	public void user_opens_the_browser_url() {
		
		System.out.println("opens browser");
	   
	}

	@Given("user enters the username as {string}")
	public void user_enters_the_username_as(String string) {
		System.out.println("Uname entered");
	   
	}

	@Given("user enters the password as {string}")
	public void user_enters_the_password_as(String string) {
		System.out.println("password eneterd");
	   
	}

	@When("user clicks on login button")
	public void user_clicks_on_login_button() {
		
		System.out.println("login button clicked");
	   
	}

	@Then("user will be navigated to the homepage of the application")
	public void user_will_be_navigated_to_the_homepage_of_the_application() {
	   
		System.out.println("navigated to homepage");
	}
	
	@When("user gets an error with incorrect credentials")
	public void user_gets_an_error_with_incorrect_credentials() {
		
		System.out.println("incorrect credetials entered");
	   
	}
	
	@Then("user will then search for {string}")
	public void user_will_then_search_for(String string) {
		
		System.out.println("product searched");
	   
	}

	@Then("user hits enter")
	public void user_hits_enter() {
		
		System.out.println("user hits eneter");
	    
	}

	@Then("a list of mentioned {string} should be displayed")
	public void a_list_of_mentioned_should_be_displayed(String string) {
		
		System.out.println("list of product displayed");
	   
	}
	
	
	@Then("user tries to look for the search history")
	public void user_tries_to_look_for_the_search_history() {
		
		System.out.println("user search for order history");
		
		
	   
	}

	@Then("user checks that {int} products he searched in last {int} days")
	public void user_checks_that_products_he_searched_in_last_days(Integer int1, Integer int2) {
	    
		System.out.println("user validates 20 products");
	}

	@Then("user wants to look for details for products")
	public void user_wants_to_look_for_details_for_products() {
		
		System.out.println("user want to see details for 20 products");
	    
	}
	
	
	@Given("user opens the application form")
	public void user_opens_the_application_form() {
		
		driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	   
	}

	@Given("user enters the below details")
	public void user_enters_the_below_details(io.cucumber.datatable.DataTable userDetails) {
	   
	List<List<String>> li=	userDetails.asLists(String.class);
	driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(li.get(1).get(0));
	driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(li.get(1).get(1));
	driver.findElement(By.xpath("//textarea[@rows=3]")).sendKeys(li.get(1).get(2));	
	driver.findElement(By.xpath("//input[@type='email']")).sendKeys(li.get(1).get(3));	
		
	}
	
	
	@Given("user opens the guru99 registration form")
	public void user_opens_the_guru99_registration_form() {
		
		driver.get("https://demo.guru99.com/V4/index.php");
		driver.manage().window().maximize();
	   
	}

	@Given("user enters the username as {string} in form")
	public void user_enters_the_username_as_in_form(String username) {
		
		driver.findElement(By.xpath("//input[@name='uid']")).sendKeys(username);
		
	   
	}

	@Given("user enters the password as {string} in form")
	public void user_enters_the_password_as_in_form(String password) {
		
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
	   
	}

	@When("user clicks on the login button")
	public void user_clicks_on_the_login_button() {
	    
		driver.findElement(By.xpath("//input[@name='btnLogin']")).click();
	}

	@Then("user will be navigated to guru99 homepage")
	public void user_will_be_navigated_to_guru99_homepage() throws Exception {
		
		String title=driver.getTitle();
		Thread.sleep(5000);
		if(title.contains("Guru99 Bank Manager HomePage"))
		{
			System.out.println("Test case passed");
		}
		
		else
		{
			throw new Exception("Page not found");
		}
		
		
		
		/// Guru99 Bank Manager HomePage 
	   
	}



	

}
