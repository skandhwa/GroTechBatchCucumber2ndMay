package StepDefinition20;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions

(
		features="src/test/java/FeatureFiles/",
		glue= {"StepDefinition20"},
		tags="@sanity2",
		dryRun=true,
		monochrome=false,
		
		
	plugin= {"pretty","html:target/HtmlReport/index.html"}	
		
		
		)





public class TestRunner {

}
